import django

print(django.db.connection.ensure_connection())