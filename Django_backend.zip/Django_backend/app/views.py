from django.shortcuts import render
from django.http import HttpResponse


#si recibimos un request para ir a index se llamara a esta funcion y retornara el valor consecuente
#para llamar este view tendremos que configurarlo con un URL
def index(request):
	return HttpResponse('Hello World, this is the App homepage')

# Create your views here.
