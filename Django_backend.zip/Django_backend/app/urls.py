from django.urls import path
from . import views

#aqui ponemos los diferentes urls a los que se puede acceder dentro de la app de polls
urlpatterns = [path('', views.index, name = 'index')]