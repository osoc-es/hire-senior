from django.urls import path
from . import views

#aqui ponemos los diferentes urls a los que se puede acceder dentro de la app de polls
urlpatterns = [
			path('', views.index, name = 'index'),
			path('register/user/', views.register_user, name = 'register_user'), 
			path('register/company/', views.register_company, name = 'register_company')
]