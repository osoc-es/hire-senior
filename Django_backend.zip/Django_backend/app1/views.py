from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader

# Create your views here.
#if we recieve a request to go to the index page it will redirect here and return the value specified
#para llamar este view tendremos que configurarlo con un URL
def index(request):
	template = loader.get_template('app1/index.html')
	return HttpResponse(template.render())

def register_user(request):
	return HttpResponse('')

def register_company(request):
	return HttpResponse('')

def login(request):
	return HttpResponse('')			

